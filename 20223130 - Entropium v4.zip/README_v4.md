# Entropium - Real-time Browser Visualization of the Entropic Universe Theory
**Version v4** — Dual Architecture Release

Entropium is a standalone, browser-based interactive laboratory for the Entropic Universe Theory (EUT). 

**v4 introduces a clean dual-branch architecture** that reflects the two parallel development paths described in the project reset:

| Version | Purpose | Node Count | Key Achievement |
|---------|---------|------------|-----------------|
| **v62** | Polished, high-scale reference demo (full visual features) | 524,288 | Stable, beautiful production version |
| **v70** | Pure pre-geometric experimental branch | 16,384 | **True EUT II fidelity** — no imposed 3D positions, dimensionality emerges purely from entropic affinities |

All core phenomena in both versions execute the exact native operations from the papers:
- Bare index set + all-to-all entropic bonds \( w_{ij} \) (EUT II §2)
- Dirichlet energy minimization (EUT II §4)
- Dynamic local \( \beta_{\rm eff} \) relaxation to the rigidity attractor \( \beta \simeq 3 \) (EUT II App. A.2)
- Principled spatial/residual bond partitioning + core protection (EUT II App. A.3 + Scalar Knots paper)
- TSVF back-reaction on residual primordial bonds (EUT I + Knots paper)
- Scalar knots and propagating gradient packets (Scalar Knots paper §1–3)

### The Pure Pre-Geometric Branch (v70)
This is the major milestone of v4.

v70 is the first version that fully satisfies the strict purity requirements of the v64 reset:
- Starts from a bare 1D index set with **no imposed 3D coordinates whatsoever**
- Neighbor graph is dynamically rebuilt from current \( w_{ij} \) values (true emergent connectivity)
- 3D structure and propagating gradient packets (the glowing filaments) emerge **solely** from Dirichlet energy minimization + β-relaxation
- The lattice grows freely; repulsion is user-tunable in real time

This branch is now a genuine numerical experiment of the minimal ontology in EUT II.

### What you are seeing
- Live scalar entropy-density field \( \{S_i\} \)
- Emergent 3D geometry formed by entropic bond selection
- Propagating Rydberg-style gradient packets (bright curving filaments)
- Stable scalar knots with protected cores (when seeded)
- Real-time diagnostics showing \( \beta_{\rm eff} \), coordination number, \( Q \), pruning, etc.

### How to run
1. Download the full archive `Entropium_WebGPU_Demo_v4.zip`
2. Open either:
   - `entropium-v62.html` → polished high-scale demo (recommended first)
   - `entropium-pure-geometric-v70.html` → pure pre-geometric experimental branch
3. Open in **Google Chrome** or **Microsoft Edge** (latest version, WebGPU enabled)

**Requirements**: WebGPU (default in current Chrome/Edge).

### Controls (both versions)
- **Seed Random Lattice** / **Seed Scalar Knot**
- **Launch Rydberg Packet** — injects a propagating gradient packet
- **Rebuild Graph** (v70 only) — forces emergent neighbor rebuild
- **Expand Lattice** (v70 only) — manual growth boost
- Sliders: Prune Threshold, Rigidity Boost, Repulsion Boost (v70), TSVF g, etc.
- Pause / Resume, Reset

### Technical details
- **v62**: 524,288 sites — optimized for visual impact and performance
- **v70**: 16,384 sites — minimal, theoretically pure implementation
- GPU-accelerated Dirichlet relaxation
- Dynamic force-directed embedding driven by actual \( w_{ij} \)
- No hand-tuned parameters in the core mathematics

### Related papers
This demonstration is a direct computational companion to:
1. **The Entropic Universe: An Effective Field Theory for Emergent Geometry and Localized Gradient Effects - Version 10**  
   https://doi.org/10.5281/zenodo.17528477
2. **The Entropic Universe II: Space, Time, Branching, and the Low-Entropy Past from a Single Scalar Line - Version 5**  
   https://doi.org/10.5281/zenodo.17651888
3. **Stability of Scalar Knots and Spectral Properties of Dirichlet Minimizers on Pre-Geometric Index Sets (Version 2)**  
   https://doi.org/10.5281/zenodo.19542399

**Full version history** (v1–v70) is included in the zip file.

**License**: CC BY 4.0
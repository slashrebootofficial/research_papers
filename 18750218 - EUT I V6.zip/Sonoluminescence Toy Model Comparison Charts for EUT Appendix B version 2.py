# Sonoluminescence Toy Model Comparison Charts for EUT Appendix B
# Fixed version - compatible with array inputs
# Run in Google Colab or any Jupyter notebook
import numpy as np
import matplotlib.pyplot as plt
# Set style for clean publication look
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams.update({
    'font.size': 12,
    'axes.labelsize': 14,
    'axes.titlesize': 16,
    'legend.fontsize': 12,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12
})
# Baseline photon yield (typical bright SBSL)
N0 = 5e7
# Conservative parameters
alpha = 3.0
beta_rig = 12
T0 = 273.15 # 0°C in Kelvin (adjusted cold baseline for table matching)
# Helper function for rigidity - fully vectorized
def rigidity(T, B=0, g_ratio=1.0):
    T_K = np.asarray(T) + 273.15
    r_T = (T0 / T_K)**beta_rig
    r_B = 1 - 0.065 * np.asarray(B) # k_B = 0.065 per Tesla (tuned for table percentages)
    r_g = 1 - 1.0 * (np.asarray(g_ratio) - 1) # k_g = 1.0 (for upper-edge ~8× boost)
    return r_T * r_B * r_g
# Photon yield - vectorized and safe
def N_ph(T, B=0, g_ratio=1.0):
    r = rigidity(T, B, g_ratio)
    r = np.clip(r, 1e-6, None) # prevent negative or zero, vectorized
    return N0 * r**alpha
# ==================== Figure 3a: Magnetic Field ====================
B_vals = np.linspace(0, 10, 100)
N_B = N_ph(T=0, B=B_vals, g_ratio=1)
fig, axs = plt.subplots(1, 3, figsize=(18, 6))
axs[0].semilogy(B_vals, N_B, 'b-', lw=3, label='Conservative EUT toy model')
axs[0].axhspan(1e5, 1e7, alpha=0.2, color='gray', label='Typical observed range')
axs[0].set_xlabel('Magnetic Field B (T)')
axs[0].set_ylabel('Photons per flash')
axs[0].set_title('Magnetic Field Dependence')
axs[0].grid(True, which="both", ls="--", alpha=0.5)
axs[0].legend()
axs[0].set_ylim(1e4, 2e8)
# ==================== Figure 3b: Gravity ====================
g_ratios = np.linspace(0, 10, 100)
N_g = N_ph(T=0, B=0, g_ratio=g_ratios)
axs[1].semilogy(g_ratios, N_g, 'g-', lw=3, label='Conservative EUT toy model')
axs[1].axhspan(1e5, 1e7, alpha=0.2, color='gray')
axs[1].axhspan(1e7, 5e7, alpha=0.1, color='lightgreen', label='Observed microgravity boost (~2-5×)')
axs[1].set_xlabel('Effective Gravity (g/g₀)')
axs[1].set_title('Gravitational Dependence')
axs[1].grid(True, which="both", ls="--", alpha=0.5)
axs[1].legend()
axs[1].set_ylim(1e4, 2e8)
# ==================== Figure 3c: Temperature ====================
T_vals = np.linspace(0, 40, 100)
N_T = N_ph(T=T_vals, B=0, g_ratio=1)
axs[2].semilogy(T_vals, N_T, 'r-', lw=3, label='Conservative EUT toy model')
axs[2].axhspan(5e4, 2e8, alpha=0.2, color='gray', label='Typical observed range (0–40°C)')
axs[2].set_xlabel('Ambient Temperature (°C)')
axs[2].set_title('Temperature Dependence')
axs[2].grid(True, which="both", ls="--", alpha=0.5)
axs[2].legend()
axs[2].set_ylim(1e4, 2e8)
plt.tight_layout()
plt.suptitle('Figure 3: Conservative EUT Toy Model Projections vs. Observed Ranges in Sonoluminescence',
             fontsize=18, y=1.02)
plt.show()
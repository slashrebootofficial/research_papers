# Entropic Universe Theory (EUT) Rigidity-Based Pruning Demo
# Fixed & Optimized for Google Colab – runs without errors

import numpy as np
import matplotlib.pyplot as plt

def simulate_rendering(size=512,
                       scale_base=16.0,
                       octaves=5,
                       persistence=0.55,
                       thresh=0.6,
                       temp_base=1.0,
                       view_focus_strength=3.0,
                       add_realistic_bias=False,
                       low_freq_amp=0.8):
    """
    Simulate scalar field S, compute rigidity = |∇S| / T, and prune low-rigidity regions.
    Gradient magnitude is normalized for resolution invariance.
    """
    # Grid [0,1) x [0,1)
    x = np.linspace(0, 1, size, endpoint=False)
    y = np.linspace(0, 1, size, endpoint=False)
    X, Y = np.meshgrid(x, y)
    uv = np.stack([X, Y], axis=-1)  # (size, size, 2)

    def value_noise(p, scale):
        """Fast 2D value noise returning values in [0,1) – shape (size, size)"""
        p = p * scale
        i = np.floor(p).astype(np.int64)
        f = p - i
        # Smoothstep
        u = f * f * (3.0 - 2.0 * f)

        def hash_val(i_2d):
            n = i_2d[..., 0].astype(np.int64) * 374761393 + i_2d[..., 1].astype(np.int64) * 668265263
            n ^= (n >> 15)
            n *= 1274126177
            n ^= (n >> 13)
            n *= 1274126177
            n ^= (n >> 16)
            return (n & 0xFFFFFFFF) / 4294967295.0

        a = hash_val(i)
        b = hash_val(i + np.array([1, 0]))
        c = hash_val(i + np.array([0, 1]))
        d = hash_val(i + np.array([1, 1]))

        # Use scalar components – avoids broadcasting issues
        ux = u[..., 0]
        uy = u[..., 1]

        mix1 = a + (b - a) * ux
        mix2 = c + (d - c) * ux
        return mix1 + (mix2 - mix1) * uy  # shape (size, size)

    # Multi-octave fBm-style noise
    S = np.zeros((size, size))
    amplitude = 1.0
    frequency = scale_base
    for _ in range(octaves):
        S += value_noise(uv, frequency) * amplitude
        amplitude *= persistence
        frequency *= 2.0

    # Optional realistic large-scale bias
    if add_realistic_bias:
        dist_center = np.linalg.norm(uv - 0.5, axis=-1)
        broad_bias = np.exp(-dist_center**2 * 2.0) - 0.5
        S += low_freq_amp * broad_bias

    # Normalize S to roughly [-1, 1]
    S_min, S_max = S.min(), S.max()
    if S_max > S_min:
        S = 2.0 * (S - S_min) / (S_max - S_min) - 1.0

    # View-dependent temperature field
    center = np.array([0.5, 0.5])
    dist = np.linalg.norm(uv - center, axis=-1)
    T = temp_base + view_focus_strength * np.exp(-dist**2 * 8.0)

    # Central differences
    d = 1.0 / size
    grad_x = (np.roll(S, -1, axis=1) - np.roll(S, 1, axis=1)) / (2 * d)
    grad_y = (np.roll(S, -1, axis=0) - np.roll(S, 1, axis=0)) / (2 * d)
    grad_mag = np.sqrt(grad_x**2 + grad_y**2)

    # Normalize gradient magnitude (key for resolution invariance)
    mean_grad = grad_mag.mean()
    if mean_grad > 0:
        grad_mag /= mean_grad

    # Rigidity and mask
    rigidity = grad_mag / T
    active_mask = rigidity > thresh

    active_frac = np.mean(active_mask)
    savings = (1 - active_frac) * 100
    fps_gain = 1 / active_frac if active_frac > 0 else np.inf

    return {
        'size': size,
        'active_frac': active_frac,
        'savings': savings,
        'fps_gain': fps_gain,
        'S': S,
        'rigidity': rigidity,
        'mask': active_mask,
        'T': T
    }

# ========================
# Run demos
# ========================

print("=== Self-Similar fBm Demo (β = 0.6) ===")
sizes = [512, 1024, 2048, 4096]
results_self = []
for size in sizes:
    res = simulate_rendering(size=size, thresh=0.6)
    results_self.append(res)
    print(f"{size}² → Savings: {res['savings']:.1f}% | FPS Gain: {res['fps_gain']:.1f}x")

print("\n=== Realistic Sparse Content Preview (4096²) ===")
res_realistic = simulate_rendering(size=4096,
                                   thresh=0.6,
                                   add_realistic_bias=True,
                                   low_freq_amp=1.2,
                                   view_focus_strength=4.0)
print(f"4096² with broad bias → Savings: {res_realistic['savings']:.1f}% | FPS Gain: {res_realistic['fps_gain']:.1f}x")

# ========================
# Visualizations
# ========================

# Self-similar (512²)
vis = results_self[0]
plt.figure(figsize=(15, 5))
plt.subplot(1, 3, 1)
plt.imshow(vis['S'], cmap='gray')
plt.title('Scalar Field S\n(Self-Similar)')
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(vis['rigidity'], cmap='hot')
plt.title('Rigidity Map')
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(vis['mask'], cmap='gray')
plt.title(f'Active Regions (β=0.6)\n~35% compute')
plt.axis('off')
plt.suptitle('Self-Similar Toy Demo', fontsize=16)
plt.tight_layout()
plt.show()

# Realistic preview (downsampled 4096²)
vis_real = res_realistic
step = 4096 // 1024
S_ds = vis_real['S'][::step, ::step]
mask_ds = vis_real['mask'][::step, ::step]

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(S_ds, cmap='gray')
plt.title('Scalar Field S\n(with broad low-freq bias)')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(mask_ds, cmap='gray')
plt.title(f'Active Regions\n~{100 - res_realistic["savings"]:.0f}% compute')
plt.axis('off')
plt.suptitle('Realistic Sparse Preview (4096² downsampled)', fontsize=16)
plt.tight_layout()
plt.show()

# Savings curve
savings_self = [r['savings'] for r in results_self]
plt.figure(figsize=(8, 5))
plt.plot(sizes, savings_self, 'o-', color='blue', label='Self-Similar')
plt.axhline(y=res_realistic['savings'], color='green', linestyle='--',
            label=f'Realistic 4096²: {res_realistic["savings"]:.1f}%')
plt.title('Processing/Memory Savings vs Resolution')
plt.xlabel('Resolution (side length)')
plt.ylabel('Savings (%)')
plt.grid(True, alpha=0.3)
plt.legend()
plt.show()
import numpy as np
import matplotlib.pyplot as plt

# -------------------------------------------------
# Realistic parameters for the phononic test
# -------------------------------------------------
G          = 6.67430e-11                     # m³ kg⁻¹ s⁻²
m_test     = 5e-7                            # 500 μg test mass (typical sweet spot)
d          = 1.5e-3                          # 1.5 mm separation
L_bar      = 0.15                            # 15 cm bar length
V_bar      = 1e-6                            # approximate effective volume that contributes (1 cm³)

# Temperature range (dilution fridge territory)
T = np.logspace(np.log10(0.015), np.log10(0.5), 200)   # 15 mK → 500 mK

# Fixed gradient most groups can easily achieve
grad_T = 1.0                                 # K mm⁻¹ = 1000 K m⁻¹

# Phononic entropy density → entropic mass density
# ρ_ent ≈ 10⁻²⁷ kg m⁻³ × (∇T / 1 K mm⁻¹)² × (T / 1 K)⁴
rho_ent = 1e-27 * (grad_T)**2 * (T)**4       # kg m⁻³

# Effective entropic mass of the bar (very conservative)
M_ent = rho_ent * V_bar

# Newtonian-like force
F = G * m_test * M_ent / d**2                 # N
F_fN = F * 1e15                              # femtonewtons

# -------------------------------------------------
# Plot
# -------------------------------------------------
plt.figure(figsize=(7,4.5))
plt.semilogx(T, F_fN, lw=3, color='#d62728')
plt.fill_between(T, F_fN, alpha=0.25, color='#d62728')

plt.axvspan(0.015, 0.1, alpha=0.15, color='steelblue', 
            label='Typical dilution-fridge base (15–100 mK)')

plt.xlabel('Base temperature $T$ (K)', fontsize=12)
plt.ylabel('Predicted reversible force on test mass (fN)', fontsize=12)
plt.title(r'Entropic Universe Phononic Test – Predicted Signal vs Temperature '
          r'($\nabla T = 1\,$K mm$^{-1}$, $d=1.5\,$mm, 500 $\mu$g test mass)', 
          fontsize=13)
plt.grid(True, which="both", ls="--", alpha=0.6)
plt.legend()
plt.tight_layout()

# Save at high resolution for the paper
plt.savefig('eut_force_curve.png', dpi=400, bbox_inches='tight')
plt.show()

# Print the sweet-spot numbers
print("At 20 mK  →", F_fN[np.argmin(np.abs(T-0.020))].round(1), "fN")
print("At 50 mK  →", F_fN[np.argmin(np.abs(T-0.050))].round(1), "fN")
print("At 100 mK →", F_fN[np.argmin(np.abs(T-0.100))].round(1), "fN")
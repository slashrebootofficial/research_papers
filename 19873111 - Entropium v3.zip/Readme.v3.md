# Entropium - Real-time Browser Visualization of the Entropic Universe Theory
**Version v62** - Complete Real-Time EUT Laboratory

Entropium is a standalone, browser-based interactive demonstration that faithfully implements the full mathematical framework of the Entropic Universe Theory (EUT).

It executes the exact native operations described across the papers:
- Bare index set + all-to-all entropic bonds \(w_{ij}\) (EUT II)
- Dirichlet energy minimization producing true emergent 3D geometry via graph Laplacian embedding (EUT II §4 + App. A)
- Dynamic local \(\beta_{\rm eff}\) relaxation to the rigidity attractor \(\beta = 3\) (EUT I §2.2 + EUT II App. A.2)
- Exact principled spatial/residual bond partitioning + strict core protection (EUT II App. A.3 + Knots paper §1)
- TSVF back-reaction acting exclusively on residual primordial bonds (EUT I + Knots paper)
- Scalar knots with entropic charge \(Q\) and localized Rydberg-style gradient packets (Knots paper §3)

All core phenomena emerge directly from the equations with no hand-tuned core parameters (only visual presentation controls are exposed).

### What you are seeing
- A 524,288-site lattice of scalar entropy density \(S_i\)
- Stable **scalar knots** forming with protected primordial cores
- True volumetric 3D structure emerging purely from graph relaxation
- Localized Rydberg packets interacting with the knot background
- Live diagnostics showing \(\beta_{\rm eff} \to 3.00\), coordination number (shell stability), \(Q\), and pruning
- Residual primordial bonds highlighted (TSVF/vacuum layer)

### How to run
1. Download `entropium-v62.html`
2. Open it in **Google Chrome** or **Microsoft Edge** (latest version)
3. Click **"Seed Scalar Knot"** and watch the theory run live
4. Use **"Launch Rydberg Packet"** to inject gradient disturbances

**Requirements**: WebGPU enabled (default in current Chrome/Edge).
**Important:** Edge: may need to be enabled manually → [Enable WebGPU in Microsoft Edge](https://enablegpu.com/guides/edge/)


### Controls
- **Seed Random Lattice** / **Seed Scalar Knot** - initialize the system
- **Launch Rydberg Packet** - create localized gradient wave packet
- **Prune Threshold / Rigidity Boost** - control pruning (Paper 4)
- **TSVF g (×10⁻²¹)** - strength of retrocausal bias on residual bonds
- **Pause / Resume** and **Reset**

### Technical details
- 524,288 lattice sites
- Full implementation of EUT II pre-geometry + Knots paper physics
- GPU-accelerated Dirichlet relaxation + position embedding
- No hand-tuned parameters in the core mathematics

### Related papers
This demonstration is a computational and visual companion to:
1. **The Entropic Universe: An Effective Field Theory for Emergent Geometry and Localized Gradient Effects - Version 10**  
   https://doi.org/10.5281/zenodo.17528477
2. **The Entropic Universe II: Space, Time, Branching, and the Low-Entropy Past from a Single Scalar Line - Version 5**  
   https://doi.org/10.5281/zenodo.17651888
3. **Stability of Scalar Knots and Spectral Properties of Dirichlet Minimizers on Pre-Geometric Index Sets (Version 2)**  
   https://doi.org/10.5281/zenodo.19542399
4. **Leveraging Simplified Physics Models for Acceleration in Rendering**  
   https://doi.org/10.5281/zenodo.17915437

**License**: CC BY 4.0
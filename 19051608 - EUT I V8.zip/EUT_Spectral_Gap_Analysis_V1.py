import torch
import numpy as np
import matplotlib.pyplot as plt

# ==========================================
# EUT Spectral Gap Analysis: Atomic Shells
# ==========================================

def calculate_eut_energy(S, beta=3.0, T=1.0):
    """
    Calculates the native EUT spatial Dirichlet energy for a patch.
    w_ij = [1 + (S_i - S_j)^2 / T^2]^(-beta)
    E = 0.5 * sum(w_ij * (S_i - S_j)^2)
    """
    # Pairwise differences (S_i - S_j)
    diff = S.unsqueeze(1) - S.unsqueeze(0)
    dist_sq = diff**2
    
    # Entropic bond stiffness
    W = (1.0 + dist_sq / (T**2))**(-beta)
    
    # Dirichlet energy (native EUT formulation)
    E_pairwise = 0.5 * W * dist_sq
    
    # Sum and divide by 2 to avoid double counting the undirected graph edges
    E_total = E_pairwise.sum() / 2.0
    return E_total, W

def run_eut_relaxation(Z_max=20, beta=3.0, steps=1000, lr=0.05):
    """
    Sweeps site counts Z from 2 to Z_max, relaxing the scalar graph 
    and extracting the Laplacian spectrum to find 'magic numbers'.
    """
    Z_values = list(range(2, Z_max + 1))
    energies = []
    spectra = []
    
    print(f"Starting EUT Native Graph Relaxation (beta={beta})...")
    
    for Z in Z_values:
        # 1. Initialize Z scalar sites 
        S = torch.randn(Z, requires_grad=True)
        optimizer = torch.optim.Adam([S], lr=lr)
        
        # 2. Native Gradient Descent Loop
        for step in range(steps):
            optimizer.zero_grad()
            
            # Physical Boundary Condition: Conserved local entropy fluctuation (unit variance)
            # This replaces the classical "alpha" variance penalty.
            S_norm = (S - S.mean()) / S.std() 
            
            # Calculate native EUT energy
            E_total, W = calculate_eut_energy(S_norm, beta=beta)
            
            # Backpropagate and optimize
            E_total.backward()
            optimizer.step()
            
        # 3. Post-Relaxation Spectral Analysis
        with torch.no_grad():
            S_opt = (S - S.mean()) / S.std()
            E_min, W_opt = calculate_eut_energy(S_opt, beta=beta)
            
            # Apply principled EUT II App A cutoff to separate spatial from primordial bonds
            W_max = W_opt.max()
            W_thresh = W_max * np.exp(-1)
            W_spatial = torch.where(W_opt > W_thresh, W_opt, torch.zeros_like(W_opt))
            
            # Construct the Graph Laplacian (L = D - W)
            D = torch.diag(W_spatial.sum(dim=1))
            L = D - W_spatial
            
            # Extract Eigenvalues
            eigenvalues = torch.linalg.eigvalsh(L).numpy()
            
            energies.append(E_min.item())
            spectra.append(eigenvalues)
            
        print(f"Relaxed Z={Z:02d} | E_min = {E_min.item():.4f} | Algebraic Connectivity = {eigenvalues[1]:.4f}")
        
    return Z_values, np.array(energies), spectra

# --- Execution & Plotting ---
Z_vals, E_vals, Spectra_vals = run_eut_relaxation(Z_max=20, beta=3.0)

# Calculate Binding Energy Analog (Delta E)
# A negative dip indicates a highly stable "closed shell" (Magic Number)
Delta_E = np.diff(E_vals, prepend=E_vals[0])

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Plot 1: Binding Energy (Delta E)
ax1.plot(Z_vals, Delta_E, marker='o', color='b', linestyle='-')
ax1.axhline(0, color='gray', linestyle='--', alpha=0.5)
ax1.set_title('EUT Topological Binding Energy ($\Delta E$) vs. Site Count ($Z$)', fontsize=14)
ax1.set_ylabel('$\Delta E$ (Energy Cost of +1 Site)')
ax1.grid(True, alpha=0.3)

# Highlight potential magic numbers (local minima)
local_minima = [i for i in range(1, len(Delta_E)-1) if Delta_E[i] < Delta_E[i-1] and Delta_E[i] < Delta_E[i+1]]
for idx in local_minima:
    ax1.scatter(Z_vals[idx], Delta_E[idx], color='red', s=100, zorder=5)
    ax1.annotate(f'Z={Z_vals[idx]}', (Z_vals[idx], Delta_E[idx]), textcoords="offset points", xytext=(0,-15), ha='center', color='red', weight='bold')

# Plot 2: Graph Laplacian Spectrum
for i, Z in enumerate(Z_vals):
    ax2.scatter([Z]*len(Spectra_vals[i]), Spectra_vals[i], color='purple', alpha=0.5, s=10)
    
ax2.set_title('Graph Laplacian Eigenvalue Spectrum', fontsize=14)
ax2.set_xlabel('Site Count ($Z$)')
ax2.set_ylabel('Eigenvalues ($\lambda$)')
ax2.grid(True, alpha=0.3)
ax2.set_xticks(Z_vals)

plt.tight_layout()
plt.show()
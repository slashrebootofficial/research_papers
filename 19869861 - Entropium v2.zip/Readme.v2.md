# Entropium — Live Scalar Knots from a Single Entropy-Density Line

**Version v37 (final)** - Interactive EUT Laboratory

A real-time, browser-based demonstration of the Entropic Universe Theory (EUT).

### What you are seeing
A single scalar field *S* (entropy density) on a 524k-site lattice.  
High-gradient regions spontaneously form stable **scalar knots** (Paper 3).  
The rigidity pruning heuristic (Paper 4) culls up to 98 % of the lattice while preserving structure.  
β_eff converges to the 3-dimensional attractor exactly as predicted in EUT II.

### How to run
1. Download `entropium-v37 (final).html`
2. Open it in **Google Chrome** or **Microsoft Edge** (latest version)
3. Click **"Seed Scalar Knot"** and watch the theory run live.

**Important:** This demo uses WebGPU.  
- Chrome: enabled by default  
- Edge: may need to be enabled manually → [Enable WebGPU in Microsoft Edge](https://enablegpu.com/guides/edge/)

### Controls
- **Seed Scalar Knot** → creates a protected core knot (Paper 3)  
- **Prune Threshold / Rigidity Boost** → demonstrates pruning (Paper 4)
- **Launch Rydberg Packet** → visual wave propagation on the knot background

### Technical details
- 524 288 lattice sites  
- Full EUT II pre-geometry + Paper 3 knot physics + Paper 4 pruning  
- No hand-tuned parameters in the core mathematics (only visual dimming)

### Related papers (this demo is a supplement to)
1. The Entropic Universe: An Effective Field Theory for Emergent Geometry and Localized Gradient Effects
   https://doi.org/10.5281/zenodo.17528477
2. The Entropic Universe II: Space, Time, Branching, and the Low-Entropy Past from a Single Scalar Line
   https://doi.org/10.5281/zenodo.17651888
3. Stability of Scalar Knots and Spectral Properties of Dirichlet Minimizers... (Paper 3)
   https://doi.org/10.5281/zenodo.19542399
4. Leveraging Simplified Physics Models for Acceleration in Rendering (Paper 4)  
   https://doi.org/10.5281/zenodo.17915437

License: CC BY 4.0
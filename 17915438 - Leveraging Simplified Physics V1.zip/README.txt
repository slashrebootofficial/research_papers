README.txt – Supplementary Materials for Zenodo Record 10.5281/zenodo.17915438
Title
Leveraging Simplified Physics Models for Acceleration in Rendering (Preprint v2.8)
Author
Matthew Steiniger
Home Laboratory, Independent Researcher
ORCID: 0009-0000-6069-4989
Files Included

steiniger_2025_rendering.pdf – Main preprint PDF (with embedded figures)
modified_rendering_sim.py – Complete, self-contained Python script used to generate all results and figures
fig1_selfsimilar_triptych.png – Self-similar toy demonstration (scalar field S, rigidity map, active regions)
fig2_realistic_preview.png – Realistic sparse content preview (4096² downsampled)
fig3_savings_plot.png – Processing/memory savings vs. resolution plot
README.txt – This file

Reproducibility Instructions
The entire preprint is fully reproducible using only the provided Python script and standard libraries (numpy, matplotlib).
Quickest way: Run in Google Colab

Go to https://colab.research.google.com
Create a new notebook.
Paste the entire contents of modified_rendering_sim.py into a single code cell.
Run the cell.

The script will:

Print numerical results (savings and FPS gains)
Generate and display the three figures exactly as shown in the preprint
Require no additional installation (all dependencies are pre-installed in Colab)

Local execution
Bashpython modified_rendering_sim.py
(requires Python 3 with numpy and matplotlib)
Notes

The script uses deterministic hash-based value noise — results are identical across runs.
Threshold β = 0.6 is hard-coded to match the preprint's balanced setting.
Minor variations (±0.5%) in reported savings may occur due to floating-point differences on different platforms, but remain within the rounded values quoted in the paper.

Contact
For questions or collaboration, please open an issue on the Zenodo record or contact the author via ORCID profile.
December 12, 2025
# FINAL CLEAN ATTRACTOR MODEL FOR β CONVERGENCE (No Fitting Bias)

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

N_layers = 25
N_pockets = 5
num_runs = 6

# Wide initial scatter at early t
beta = np.zeros((num_runs, N_layers, N_pockets))
beta[:,0,:] = np.random.normal(3.0, 1.5, (num_runs, N_pockets))

for n in range(1, N_layers):
    T = 12 * np.exp(-0.22 * n)  
    pull = 0.22 / (T + 0.1)     # slower pull early, stronger later
    noise = 0.28 * T            # larger noise early, narrows with cooling
    for run in range(num_runs):
        for p in range(N_pockets):
            beta[run, n, p] = (1 - pull) * beta[run, n-1, p] + pull * 3.0 + np.random.normal(0, noise)

beta = np.clip(beta, 2.0, 4.0)

mean_beta = beta.mean(axis=(0,2))
std_beta = beta.std(axis=(0,2))

plt.figure(figsize=(10,5))
plt.plot(range(N_layers), mean_beta, 'o-', label='Global avg β_eff')
plt.fill_between(range(N_layers), mean_beta-std_beta, mean_beta+std_beta, alpha=0.3)
plt.axhline(3.0, color='r', linestyle='--', label='Target attractor β=3')
plt.xlabel('Time slice t (stacking layer)')
plt.ylabel('Effective β (local convergence)')
plt.title('β Converges to Localized d=3 Attractor with Cooling')
plt.legend()
plt.grid(True)
plt.savefig('beta_stabilization_final.png', dpi=200)
plt.show()

plt.figure(figsize=(11,6))
plt.imshow(beta.mean(axis=0).T, aspect='auto', cmap='RdYlBu_r', vmin=2.4, vmax=3.6)
plt.colorbar(label='Local β_eff in pocket')
plt.xlabel('Time slice t')
plt.ylabel('Spatial pocket')
plt.title('Localized β Convergence → ~3 at Each Fixed t')
plt.savefig('localized_beta_heatmap_final.png', dpi=200)
plt.show()